/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ERTSim;

/**
 *
 * @author thetr
 */
public enum EmergencySeverityIndex
{
    _1_Resuscitation, _2_Emergent, _3_Urgent, _4_LessUrgent, _5_Nonurgent, _6_Ded
}
